<?php
/**
 * Récupère le quota IA restant (Pro)
 * @return int
 */
function aam_get_ia_quota() {
    // TODO : intégrer gestion réelle des quotas IA
    return 0;
}
