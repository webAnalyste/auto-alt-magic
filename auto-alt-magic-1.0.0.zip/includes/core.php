<?php
/**
 * Traite le post_content pour injecter ALT et TITLE dans les balises <img>
 * Appelée sur save_post par auto-alt-magic.php
 * @param int $post_ID
 * @param WP_Post $post
 */
function aam_core_process_post($post_ID, $post) {
    // Suppression : ne plus modifier le ALT global dans la médiathèque
    // Toute la logique passe par le parsing du post_content (HTML), ALT contextuel


    // Sécurité : ne traiter que les post/page/produit publiés ou en brouillon
    if (!in_array($post->post_type, ['post', 'page', 'product'])) return;
    
    $content = $post->post_content;
    if (empty($content)) return;

    // Charger les réglages
    $method = get_option('aam_method', 'titre');
    $text_libre = get_option('aam_text_libre', '');
    $title_sync = get_option('aam_option_title_sync', 1);

    // Récupérer le focus keyword (SEO ou metabox)
    require_once AAM_PLUGIN_DIR . 'includes/seo.php';
    $mot_cle = aam_get_focus_keyword($post_ID);
    if (!$mot_cle) {
        $mot_cle = get_post_meta($post_ID, 'aam_focus_keyword', true);
    }
    $lang = get_locale();
    $type_post = $post->post_type;
    $titre = get_the_title($post_ID);

    // Utilisation de DOMDocument
    libxml_use_internal_errors(true);
    $dom = new DOMDocument('1.0', 'UTF-8');
    $dom->loadHTML('<?xml encoding="utf-8" ?>' . $content, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    $imgs = $dom->getElementsByTagName('img');
    if (!$imgs || $imgs->length === 0) return;

    // Prépare les paramètres contextuels (meta > réglages type > options globales legacy)
    $type = $post->post_type;
    $type_settings = get_option('aam_settings_' . $type, []);
    $method = get_post_meta($post->ID, 'aam_method', true)
        ?: ($type_settings['method'] ?? get_option('aam_method', 'titre'));
    $text_libre = get_post_meta($post->ID, 'aam_text_libre', true)
        ?: ($type_settings['text_libre'] ?? get_option('aam_text_libre', ''));
    $prefix = get_post_meta($post->ID, 'aam_prefix', true)
        ?: ($type_settings['prefix'] ?? get_option('aam_prefix', ''));
    $suffix = get_post_meta($post->ID, 'aam_suffix', true)
        ?: ($type_settings['suffix'] ?? get_option('aam_suffix', ''));
    $only_empty = get_post_meta($post->ID, 'aam_only_empty_alt', true);
    if ($only_empty === '') $only_empty = isset($type_settings['only_empty_alt']) ? $type_settings['only_empty_alt'] : get_option('aam_only_empty_alt', 0);
    $replace_all = get_post_meta($post->ID, 'aam_replace_all_alt', true);
    if ($replace_all === '') $replace_all = isset($type_settings['replace_all_alt']) ? $type_settings['replace_all_alt'] : get_option('aam_replace_all_alt', 0);
    $title_sync = get_post_meta($post->ID, 'aam_option_title_sync', true);
    if ($title_sync === '') $title_sync = isset($type_settings['option_title_sync']) ? $type_settings['option_title_sync'] : get_option('aam_option_title_sync', 1);
    $focus_keyword = aam_get_focus_keyword($post->ID);
    if (!$focus_keyword) {
        $focus_keyword = get_post_meta($post->ID, 'aam_focus_keyword', true);
    }
    $featured_alt = get_post_meta($post->ID, 'aam_featured_alt', true);
    $thumb_id = get_post_thumbnail_id($post->ID);
    $thumb_url = $thumb_id ? wp_get_attachment_url($thumb_id) : '';
    $titre = get_the_title($post->ID);
    $lang = get_locale();
    $type_post = $post->post_type;

    // Parcours toutes les images du contenu
    foreach ($imgs as $img) {
        $src = $img->getAttribute('src');
        $alt = $img->getAttribute('alt');
        $is_featured = ($thumb_url && $src && strpos($src, $thumb_url) !== false);
        $nom_image = '';
        if ($src) {
            $nom_image = pathinfo(parse_url($src, PHP_URL_PATH), PATHINFO_FILENAME);
        }
        // Cas featured image avec ALT manuel
        if ($is_featured && !empty($featured_alt)) {
            $alt_new = $featured_alt;
        } else {
            // Génération selon méthode
            if ($method === 'titre') {
                $alt_new = $titre;
            } elseif ($method === 'nom_fichier') {
                $alt_new = $nom_image;
            } elseif ($method === 'texte_libre') {
                require_once AAM_PLUGIN_DIR . 'includes/template-parser.php';
                $alt_new = aam_parse_template_tags($text_libre, [
                    'mot_cle' => $focus_keyword,
                    'titre' => $titre,
                    'nom_image' => $nom_image,
                    'lang' => $lang,
                    'type_post' => $type_post,
                ]);
            } else {
                $alt_new = $titre;
            }
        }
        // Hook développeur
        $alt_new = apply_filters('autoalt_custom_alt', $alt_new, $src, $post->ID, [
            'method' => $method,
            'mot_cle' => $focus_keyword,
            'titre' => $titre,
            'nom_image' => $nom_image,
            'lang' => $lang,
            'type_post' => $type_post,
            'is_featured' => $is_featured,
        ]);
        // Préfixe/suffixe
        if ($prefix) $alt_new = $prefix . ' ' . $alt_new;
        if ($suffix) $alt_new = $alt_new . ' ' . $suffix;
        $alt_new = trim($alt_new);
        // Ciblage : remplacer que si alt vide OU forcer selon option
        if (($only_empty && !$alt) || $replace_all || ($is_featured && !empty($featured_alt))) {
            $img->setAttribute('alt', esc_attr($alt_new));
            // Duplication dans title si activé
            if ($title_sync) {
                if (!$img->hasAttribute('title') || !$img->getAttribute('title')) {
                    $img->setAttribute('title', esc_attr($alt_new));
                }
            }
        }
    }
    // Sauvegarde du contenu modifié
    $new_content = $dom->saveHTML();
    // Nettoyage de l’entête XML ajouté par DOMDocument
    $new_content = preg_replace('/^<\?xml.*?\?>/', '', $new_content);
    // Mise à jour du contenu uniquement si modifié
    if ($new_content !== $content) {
        // Sécurité : update_post_meta pour éviter boucle
        
        // Désactive temporairement le hook save_post pour éviter boucle infinie
        remove_action('save_post', 'aam_process_post_content', 20);
        wp_update_post([
            'ID' => $post_ID,
            'post_content' => $new_content
        ]);
        add_action('save_post', 'aam_process_post_content', 20, 3);
    }
}
