<?php
/**
 * Détermine si l’utilisateur a le plan Pro
 * @return bool
 */
function aam_is_pro() {
    // TODO : intégrer gestion réelle des plans (licence, etc.)
    return false;
}
