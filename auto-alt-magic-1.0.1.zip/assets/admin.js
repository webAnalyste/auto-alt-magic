// JS admin Auto ALT Magic
