<?php
/**
 * Traitement par lot (batch) Pro
 * @return void
 */
function aam_batch_process() {
    // TODO : implémenter batch (Pro)
}
